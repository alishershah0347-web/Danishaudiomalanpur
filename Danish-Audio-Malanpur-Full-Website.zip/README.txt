DANISH AUDIO MALANPUR WEBSITE
Files:
- index.html
- amplifier-1.jpeg
- amplifier-2.jpeg

Phone: 7489340335
Pro: Shahenshah Bhai

WhatsApp link is already configured.
For free hosting, upload these files to a static host such as GitHub Pages.
